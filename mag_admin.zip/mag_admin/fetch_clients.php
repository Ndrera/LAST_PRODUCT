<?php
require_once 'core/init.php';


$data = DB::getInstance()->query("SELECT b.id, b.branch_name, b.branch_code, b.branch_credits, b.branch_contact, b.branch_email, b.date_modified, ba.suspend_status 
	FROM branch b 
	INNER JOIN branch_additionals ba ON b.id = ba.branch_id");


$output 		= '';
$option 		= '';
$active_button  = '';
if( !$data->count() ){
    #NO DATA FOUND IN THE DATABASE
	$output .= "
	<tr>
	    <td>No table records are found on this table.</td>
	</tr>
	";

}else{

	$x = 1;
	foreach( $data->results() as $result ){



		if( $result->suspend_status == 1 ){
	  		$active_button = '<button type="button" name="suspend" id="' . $result->id . '" class="btn btn-success btn-block suspend">Un-Suspend</button>';
	  	}else{
	  		$active_button = '<button type="button" name="suspend" id="' . $result->id . '" class="btn btn-danger btn-block suspend">Suspend</button>';
	  	}

		$output .= '
		    <tr>
		      <th>'. $x .'</th>
		      <th>' . $result->branch_name . '</th>
		      <th><p style="color:#C9302C">' . $result->branch_code . '</p></th>
		      <th><input type="text" name="branch_credits" id="branch_credits" value=" ' . $result->branch_credits . ' " class="form-control border-color" disabled></th>
		      <th><p style="color:green">' . $result->branch_email . '</p></th>
		      <th><p style="color:#31B0D5">' . $result->branch_contact . '</p></th>
		      <th>' . $result->date_modified . '</th>
		      <th>' . $active_button  . '</th>
		      <th><button type="button" name="edit" id="' . $result->id . '" class="btn btn-primary btn-block edit">Edit</button></th>
		    </tr>';

		$output .= $x < count( $data->results() ) ? "<hr/>" : "";
		$x++;

		
	}

}


echo $output;



?>