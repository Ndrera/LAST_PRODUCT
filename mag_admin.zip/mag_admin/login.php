<?php
require_once 'core/init.php';


if( Input::exists() ){
	if( Token::check(Input::get('token')) ){


		$output = "";

		#Validate
		$validate 	= new Validate();
		$validation = $validate->check( $_POST, array(

			  'username' => array( 'required' => true ),
			  'password' => array( 'required' => true )
		) );

		#Validation successful
		if( $validation->passed() ){

			$user = new User();	

			$remember = ( Input::get('remember') === 'on' ) ? true :false;

			$login = $user->login( Input::get('username'), Input::get('password'), $remember );

			if( $login ){  
				Redirect::to('index.php');

			}else{
				Session::flash( 'output', "<div class='alert alert-danger'>Sorry, logging in failed.</div>" );
			}


		}else{

			#Otherwise the are errors
			foreach( $validation->errors() as $error ){
				//echo $error, "<br/>";

				$output .= $error . '.<br/>';
				Session::put( 'output', "<div class='alert alert-danger'>" . $output . "</div>" );
			}
		}


	}
}


?>

<!DOCTYPE html>
<html>
<head>
	<title>A.I.S</title>
	<meta name="viewport" content="width=device-width, initial-sacle=1">
	<script type="text/javascript" src="js/jquery.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">
	<script type="text/javascript" src="js/bootstrap.min.js"></script>

	<style type="text/css">
       
       
		body  {
		  /*background-image: url("images/2.jpg") !important; 
		   background-image: url("images/bg4.jpg") !important; */

		  background-image: url("images/2.jpg") !important;
		  background-color: #cccccc !important;

		}

	</style>

</head>
<body> 

	<!-- # NAV -->
	<nav class="nav navbar-inverse">
		<div class="container">
			
		<a class="navbar-brand" href="index.php">Advanced Intelligence System</a>
			
		</div>
	</nav>

	<!-- # CONTAINER -->
	<div class="container container-bg">
		<div class="row">

			<!-- #COLUM1 - SIDE col2 -->
			<div class="col-md-6">
			    <p>
					<div class="well border-color">
					<!-- # WELL <div class="well"> -->

						 <ul class="list-group">
					   	 <li class="list-group-item">

					   	 <div id="results" class="text-center">
					        <?php
					 		   if( Session::exists('output') ){
					 		   	   echo  Session::flash('output');

								}
					 		 ?>
					   	 </div>
					   	

						 <form action="" method="post" id="login_form">


							 
						 	<table class="table">
						 		<thead class="thead-dark">
						 			<tr>
						 				<th><h3>Sign In:</h3></th>
						 				<th><h3 style="color: red;"><?php echo date('Y-m-d H:i:s'); ?></h3></th>
						 			</tr>
						 		</thead>

						 		<tbody>
						 			
						 			<tr>
						 				<td colspan="2">
						 					<div class="form-group">
							   	  	 			<label>Username:</label>

							   	  	 			<input type="text" name="username" id="username" class="form-control border-color">
							   	  	 		</div>
						 				</td>

						 			</tr>

						 			<tr>

						 				<td colspan="2">
							   	  	 		<div class="form-group">
							   	  	 			<label>Password:</label>
							   	  	 			<input type="password" name="password" id="password" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

						 			</tr>

						 			<tr>
						 				
						 				<td>
											<div class="form-group">
											   <label for="remember">
											   	   <input type="checkbox" name="remember" id="remember" class="border-color">
											   	   Remember me
											   </label>
											</div>
						 				</td>

						 			</tr>

						 			<tr>
							   	  	 	<td colspan="2">
							   	  	 		<div class="form-group">
							   	  	 			<input type="hidden" name="token" value="<?php echo Token::generate(); ?>">
							   	  	 			<input type="hidden" name="action" id="action" value="" >
							   	  	 			<input type="submit" name="login" value="Login" class="btn btn-primary btn-block">
							   	  	 		</div>
							   	  	 	</td>
							   	  	 </tr>

						 		</tbody>
						 	</table>

						 
					   	  	
					   	  </form>

					   	 </li>
					   	 </ul>

					</div>
				</p>
			</div>	


			<!-- #ADD IT HERE OR ANOTHER ROW, OUTSIDE -->
			<div class="col-md-6">
			    <p>
					<div class="well border-color">
					<!-- # WELL <div class="well">  img-thumbnail -->

						 <ul class="list-group">
					   	 <li class="list-group-item">

					   	 
					   	 <img class="img-fluid" src="images/log2.png" style="width: 100%;height: 132px;">
					   	 <img class="img-fluid" src="images/bi2.png" style="width: 100%;height: 132px;">
					   	 <img class="img-fluid" src="images/log4.jpg" style="width: 100%;height: 132px;">
					   	 
					   	 
					   	 </li>
					   	 </ul>

					</div>
				</p>
			</div>	


		</div>
	</div>


	<!-- # FOOTER -->
	
	<footer class="footer navbar-fixed-bottom text-center">
		<p>Copyright <?php echo date('Y'); ?> &copy; A.I.S</p>
	</footer>

</body>
</html>

<script type="text/javascript">
$(document).ready( function(){

} );

</script>