<?php
require_once 'core/init.php';

$user = new User();
if( !$user->isLoggedIn() ){
 	//Redirect::to('index.php');
 	Redirect::to('login.php');
}


?>

<!DOCTYPE html>
<html>
<head>
	<title>A.I.S</title>
	<meta name="viewport" content="width=device-width, initial-sacle=1">
	<script type="text/javascript" src="js/jquery.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body>

	<!-- # NAV -->
	<nav class="nav navbar-inverse">
		<div class="container">
			
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="index.php">Advanced Intelligence System</a>
			</div>

			<div id="navbar" class="collapse navbar-collapse">
				<ul class="nav navbar-nav" id="_links">
		
					<li class=""><a href="index.php">Home</a></li>
					<li class=""><a href="register.php">Add User</a></li>
					<li class=""><a href="add_client.php">Add Client</a></li>
					<li class=""><a href="billing.php">Billing</a></li>
					<li class=""><a href="logout.php">Logout</a></li>
					<!-- 
					<li id="_li"></li>
					-->

				</ul>
			</div>

		</div>
	</nav>


	<!-- # CONTAINER -->
     <div style="padding-right: 40px !important; padding-left: 40px !important;">
			    <p>
					<div class="well border-color">
					<!-- # WELL <div class="well"> -->
						  
						 
						
					    <table class="table">
						 		<thead class="thead-dark">
						 			<tr>
						 				<th colspan="2" ><h3>Clients:</h3></th>
						 			</tr>
						 		</thead>

						 		
						 </table>


						 <ul class="list-group">
					   	 <li class="list-group-item">

					   	 <img class="img-fluid img-rounded" src="images/bi2.png" style="width: 100%;height: 95px;">


					   	  <hr/>

					   	 <!-- #NAVIGATION BUTTON -->


					   	 <div id="success_msg" class="text-center">
					 
					   	 </div>

					   	 <div id="results" class="text-center">
					 
					   	 </div>
					   	
					   
						 <form action="" method="post" id="search_form">

						 	<div class="table-responsive">

						 	<table class="table">
							  <thead class="thead-dark">
							    <tr>
							      <th class="success" scope="col">#</th>
							      <th class="success" scope="col">Client Name</th>
							      <th class="success" scope="col">Client Code</th>
							      <th class="success" scope="col">Available Credits</th>
							      <th class="success" scope="col">Email</th>
							      <th class="success" scope="col">Phone Number</th>
							      <th class="success" scope="col">Created At</th>
							      <th class="success" scope="col">Suspend</th>
							      <th class="success" scope="col">Update</th>
							    </tr>
							  </thead>

							  <tbody id="clients_output"></tbody>

							</table>

						</div>

						
					   	  	
					   	  </form>

					   	 </li>
					   	 </ul>

					</div>
				</p>

	 </div>
			



	<!-- # FOOTER -->
	<footer class="footer navbar-fixed-bottom text-center">
		<p>Copyright <?php echo date('Y'); ?> &copy; A.I.S </p>
	</footer>

</body>
</html>

<script type="text/javascript">
$(document).ready( function(){

	//NOTE THESE ARE CLIENTS
	fetch_data();

	function fetch_data(){

		$.ajax({
			url:"fetch_clients.php",
			success:function(data){

				$('#clients_output').html(data);
			}
		})
	}


	//SUSPEND USER: SET 1 True, 0 = False (Not Suspened)
	$(document).on('click', '.suspend', function(){

        	var suspend_id = $(this).attr('id');
        	var action = "suspend"; 

			$.ajax({
				url:"action.php",
				method:"POST",
				data:{suspend_id:suspend_id, action:action},
				success:function(data){

					alert(data);
					location.reload(); 
					
				}

			});

	});


	/* EDIT THE CLIENT */
	//EDIT THE CLIENT
	$(document).on('click', '.edit', function(){

		    var edit_id = $(this).attr('id');
		    window.location.href = "edit.php?id=" + edit_id;

	});


}); 

</script>