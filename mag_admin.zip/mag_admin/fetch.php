<?php
require_once 'core/init.php';

$data = DB::getInstance()->query("SELECT b.id, b.branch_name, b.branch_credits, ba.payment, ba.credit_status, b.date_modified, ba.loaded_credits 
	FROM branch b 
	INNER JOIN branch_additionals ba ON ba.branch_id = b.id");

$output 		= '';
$option 		= '';
$active_button  = '';
$payment_color  = '';
$credit_status_color = '';
if( !$data->count() ){
    #NO DATA FOUND IN THE DATABASE
	$output .= "
	<tr>
	    <td>No table records are found on this table.</td>
	</tr>
	";

}else{

	$x = 1;
	foreach( $data->results() as $result ){


	  	if( $result->credit_status == "Active" ){
	  		$active_button = '<button type="button" name="activate" id="' . $result->id . '" class="btn btn-warning btn-block activate">De-Activate</button>';
	  	}else{
	  		$active_button = '<button type="button" name="activate" id="' . $result->id . '" class="btn btn-primary btn-block activate">Activate</button>';
	  	}
	   
	   	#Color [ payment ]
	   	if( $result->payment == "Success" ){
	   		$payment_color = '<p style="color:green">' . $result->payment . '</p>';
	   	}else{
	   		$payment_color = '<p style="color:red">' . $result->payment . '</p>';
	   	}

	   	#Color [ credit_status ]
	   	if( $result->credit_status == "Active" ){
	 		$credit_status_color = '<p style="color:green">' . $result->credit_status . '</p>';
	 	}else{
	 		$credit_status_color = '<p style="color:red">' . $result->credit_status . '</p>';
	 	}

	 	#<th>' . $result->credit_status . '</th>

		 $output .= '
		<tr>
		  <th>'. $x  .'</th>
		  <th>'. $result->branch_name .'</th>
		  <th>
		     <input type="text" name="branch_credits" id="branch_credits" value=" ' . $result->branch_credits . ' " class="form-control border-color" disabled
		     style="width:90px !important;">
		  </th>
		  

		  <th>
		  	<input type="text" name="loaded_credits" id="loaded_credits" value=" ' . $result->loaded_credits . ' " class="form-control border-color" disabled 
		  	style="width:90px !important;">
		  </th>

		  <th><button type="button" name="approve" id="' . $result->id . '" class="btn btn-success btn-block approve">Approve Credit</button></th>
		  <th><button type="button" name="confirm" id="' . $result->id . '" class="btn btn-info btn-block confirm">Confirm</button></th>
		  <th>'. $payment_color .'</th>
		  <th>' . $active_button . '</th>
		  <th>' . $credit_status_color . '</th>
		  <th>' . $result->date_modified . '</th>
		  <th><button type="button" name="invoice" id="' . $result->id . '" class="btn btn-danger btn-block invoice">Invoice</button></th>
		  <th><button type="button" name="statement" id="' . $result->id . '" class="btn btn-primary btn-block statement">Statement</button></th>

		</tr>';


		$output .= $x < count( $data->results() ) ? "<hr/>" : "";
		$x++;

		
	}

}


echo $output;



?>