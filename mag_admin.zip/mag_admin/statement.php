<?php

/*call the FPDF library*/
require_once 'core/init.php';
require('fpdf182/fpdf.php');

$id 			= Input::get('id');
$date_from  	= Input::get('from');
$date_to 		= Input::get('to');
$company_name 	= '';
$payment_cells 	= '';

$data_name = DB::getInstance()->query("SELECT registered_name, payment FROM branch_additionals WHERE branch_id = $id");

foreach( $data_name->results() as $name ){
	$company_name 	= $name->registered_name;
	$payment_status = $name->payment;
}


$data = DB::getInstance()->query("SELECT * FROM branch_invoice bi 
	INNER JOIN branch_invoice_additionals bia ON bi.id = bia.branch_invoice_id 
	WHERE (date_invoiced BETWEEN '$date_from' AND '$date_to') AND bi.branch_id = $id");


if( !$data->count() ){
    #NO DATA FOUND IN THE DATABASE
	echo "No statement data found";

}else{


	foreach( $data->results() as $result ){

		/*A4 width : 219mm*/
		$pdf = new FPDF('P','mm','A4');

		$pdf->AddPage();
		/*output the result*/

		/*set font to arial, bold, 14pt*/
		$pdf->SetFont('Arial','B',20);

		/*Cell(width , height , text , border , end line , [align] )*/

		#BLOCK 1
		$pdf->Cell(71 ,10, $pdf->Image('images/ict_logo.png',6,6,49),0,0);
		$pdf->Cell(59 ,5,'',0,0);
		$pdf->Cell(59 ,10,'STATEMENT',0,1);
		$pdf->Ln(24);

		$pdf->SetFont('Arial','B',10);

		$pdf->Cell(130 ,5,'',0,0);    //ADDIND SPACE
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,'Platinum ICT (Pty) LTD',0,0);  
		$pdf->Cell(25 ,5,'Cust Id:',0,0);
		//$pdf->Cell(34 ,5, "M" . $result->invoice_no,0,1);
		$pdf->Cell(34 ,5, $result->invoice_reference,0,1);

		$pdf->Cell(130 ,5,'VAT No: 4380274177',0,0);
		$pdf->Cell(25 ,5,'Date:',0,0);
		$pdf->Cell(34 ,5, $result->date_invoiced,0,1);
		 

		$time = strtotime( $result->date_invoiced );
		$final = date("Y-m-d", strtotime("+1 month", $time));

		$pdf->Cell(130 ,5,'Reg: 2014/281031/07',0,0);
		$pdf->Cell(25 ,5,'Print Date:',0,0);
		$pdf->Cell(34 ,5, date("Y-m-d"),0,1);

		$pdf->Cell(130 ,5,'Unit 6b Monpark Center',0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,'76 Skilpad Street',0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,'Monument Park, Pretoria',0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,'0181',0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,'',0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);


		#BLOCK 3
		$pdf->SetFont('Arial','B',15);
		$pdf->Cell(130 ,5,'Invoice To:',0,0);
		$pdf->Cell(59 ,5,'',0,0);
		$pdf->SetFont('Arial','B',10);
		$pdf->Cell(189 ,10,'',0,1);


		$pdf->Cell(130 ,5,$company_name,0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,$result->recipient_address_line1,0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,$result->recipient_address_line2,0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,$result->recipient_address_line3,0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,$result->recipient_address_line4,0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);



		#BLOCK 4
		#$pdf->Cell(50 ,10,'',0,1);
		$pdf->SetDrawColor(194, 193, 190);
		$pdf->SetFillColor(194, 193, 190);

		$pdf->SetFont('Arial','B',10);
		/*Heading Of the table*/
		$pdf->Cell(10 ,6,'No',0,0,'L', true);
		$pdf->Cell(25 ,6,'Date',0,0,'L', true);
		$pdf->Cell(39 ,6,'Reference',0,0,'L', true);
		$pdf->Cell(60 ,6,'Description',0,0,'L', true);
		$pdf->Cell(28 ,6,'Debit',0,0,'L', true);
		//$pdf->Cell(25 ,6,'Credit',1,0,'C');
		$pdf->Cell(28 ,6,'Credit',0,1,'L', true);/*end of line*/

		/*Heading Of the table end*/
		$pdf->SetFont('Arial','',10);

		    $x = 1;
		    foreach( $data->results() as $res ){

		    	$pdf->Cell(10 ,6,$x,0,0,'L');
				$pdf->Cell(25 ,6,$res->date_invoiced,0,0,'L');
				$pdf->Cell(39 ,6, $res->invoice_reference,0,0,'L');
				$pdf->Cell(60 ,6, $res->description,0,0,'L');
				
				if( $payment_status == "Success" ){
					$pdf->Cell(28 ,6, '' ,0,0,'L');
					$pdf->Cell(28 ,6, 'R'. $res->total_price,0,1,'L');

				}else if($payment_status == "Pending"){
					$pdf->Cell(28 ,6, 'R'. $res->total_price,0,0,'L');
					$pdf->Cell(28 ,6, '',0,1,'R');;
				}

				$x++;
				
			}
				
				
		$pdf->Output("I", $result->invoice_reference . ".pdf"); 


	}


} 




?>
